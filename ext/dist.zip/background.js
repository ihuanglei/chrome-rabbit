chrome.runtime.onMessage.addListener(function(message, sender, response) {})

chrome.browserAction.onClicked.addListener(function(tab) {})
